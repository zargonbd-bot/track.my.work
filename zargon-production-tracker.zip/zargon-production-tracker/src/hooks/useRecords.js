// src/hooks/useRecords.js
import { useState, useEffect, useCallback } from 'react';
import { db } from '../lib/firebase';

export function useRecords() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchRecords = useCallback(async () => {
    try {
      setLoading(true);
      const data = await db.getAll();
      setRecords(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRecords();
  }, [fetchRecords]);

  const addRecord = async (record) => {
    const newRec = await db.add(record);
    setRecords(prev => [newRec, ...prev]);
    return newRec;
  };

  const updateRecord = async (id, record) => {
    const updated = await db.update(id, record);
    setRecords(prev => prev.map(r => r.id === id ? { ...r, ...record } : r));
    return updated;
  };

  const deleteRecord = async (id) => {
    await db.delete(id);
    setRecords(prev => prev.filter(r => r.id !== id));
  };

  return { records, loading, error, addRecord, updateRecord, deleteRecord, refetch: fetchRecords };
}

// ─── Stats helpers ────────────────────────────────────────────────────────────
export function computeStats(records) {
  const totalProducts = records.length;
  const totalEditedVideos = records.reduce((s, r) => s + (r.editCreativeCount || 0), 0);
  const totalHookEdits = records.reduce((s, r) => s + (r.hookEditCount || 0), 0);
  const pendingWorks = records.filter(r => !r.photoshootCompleted).length;
  const completedWorks = records.filter(r => r.photoshootCompleted).length;

  const totalPayments = records.reduce((s, r) => {
    return s + (r.editCreativeCount || 0) * 30 + (r.hookEditCount || 0) * 10;
  }, 0);

  // Per editor
  const editors = {};
  records.forEach(r => {
    if (!editors[r.editorName]) {
      editors[r.editorName] = { name: r.editorName, editCount: 0, hookCount: 0, payment: 0, records: 0 };
    }
    editors[r.editorName].editCount += r.editCreativeCount || 0;
    editors[r.editorName].hookCount += r.hookEditCount || 0;
    editors[r.editorName].payment += (r.editCreativeCount || 0) * 30 + (r.hookEditCount || 0) * 10;
    editors[r.editorName].records += 1;
  });

  return {
    totalProducts,
    totalEditedVideos,
    totalHookEdits,
    pendingWorks,
    completedWorks,
    totalPayments,
    editors: Object.values(editors),
  };
}

export function computeMonthlyData(records) {
  const map = {};
  records.forEach(r => {
    const month = r.date?.substring(0, 7) || 'unknown';
    if (!map[month]) map[month] = { month, editVideos: 0, hookEdits: 0, payment: 0, products: 0 };
    map[month].editVideos += r.editCreativeCount || 0;
    map[month].hookEdits += r.hookEditCount || 0;
    map[month].payment += (r.editCreativeCount || 0) * 30 + (r.hookEditCount || 0) * 10;
    map[month].products += 1;
  });
  return Object.values(map).sort((a, b) => a.month.localeCompare(b.month));
}

export function computeDailyData(records) {
  const map = {};
  records.forEach(r => {
    const day = r.date || 'unknown';
    if (!map[day]) map[day] = { day, editVideos: 0, hookEdits: 0, payment: 0 };
    map[day].editVideos += r.editCreativeCount || 0;
    map[day].hookEdits += r.hookEditCount || 0;
    map[day].payment += (r.editCreativeCount || 0) * 30 + (r.hookEditCount || 0) * 10;
  });
  return Object.values(map).sort((a, b) => a.day.localeCompare(b.day)).slice(-30);
}
